# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all

datas = [('C:/Users/evere/Documents/Codex/2026-10-27/could-we-look-at-an-open/TapoDeck Submission version/09 SDK v3 Candidate/Source Code/app/web', 'app/web')]
binaries = []
hiddenimports = []
tmp_ret = collect_all('kasa')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('aiohttp')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]


a = Analysis(
    ['C:/Users/evere/Documents/Codex/2026-10-27/could-we-look-at-an-open/TapoDeck Submission version/09 SDK v3 Candidate/Source Code/app/server.py'],
    pathex=['C:/Users/evere/Documents/Codex/2026-10-27/could-we-look-at-an-open/TapoDeck Submission version/09 SDK v3 Candidate/Source Code/app'],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='TapoDeck',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
